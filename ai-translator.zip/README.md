# Global Translator Crystal

## 🚀 How to Launch in a New Repository

You want to host this on a different repository than the old one. Follow these steps to "detach" the code and start fresh.

### Step 1: Create the New Repo
Go to GitHub and create a **new empty repository**. Do not add a README or .gitignore during creation.

### Step 2: Run these commands
Open your terminal in this project folder and run these commands one by one:

```bash
# 1. Remove the old git tracking folder (Windows: rmdir /s /q .git)
rm -rf .git

# 2. Start a fresh git history
git init

# 3. Add all files
git add .

# 4. Commit the fresh version
git commit -m "Initial Crystal Release v1.0"

# 5. Rename branch to main
git branch -M main

# 6. Link to your NEW repository (Replace URL below!)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_NEW_REPO_NAME.git

# 7. Push the code
git push -u origin main
```

## Setup Keys
Remember to set your `API_KEY` in your GitHub Repository Settings under **Secrets and variables > Actions** for the deployment to work.
