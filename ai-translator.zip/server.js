import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 8080;
const DIST_DIR = path.join(__dirname, 'dist');
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.wav': 'audio/wav',
  '.mp4': 'video/mp4',
  '.woff': 'application/font-woff',
  '.ttf': 'application/font-ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'application/font-otf',
  '.wasm': 'application/wasm',
  '.xml': 'application/xml',
  '.webmanifest': 'application/manifest+json'
};

const server = http.createServer((req, res) => {
  // Normalize URL
  let url = req.url;
  if (url === '/') url = '/index.html';
  
  const cleanUrl = url.split('?')[0];
  const extname = String(path.extname(cleanUrl)).toLowerCase();
  
  let filePath = path.join(DIST_DIR, cleanUrl);

  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (!err) {
      serveFile(filePath, res, cleanUrl);
    } else {
      if (cleanUrl === '/robots.txt' || cleanUrl === '/manifest.json') {
         const publicFallback = path.join(PUBLIC_DIR, cleanUrl);
         fs.access(publicFallback, fs.constants.F_OK, (fallbackErr) => {
            if (!fallbackErr) {
                serveFile(publicFallback, res, cleanUrl);
            } else {
                res.writeHead(404);
                res.end('404 Not Found');
            }
         });
         return;
      }

      // SPA Fallback
      if (extname === '') {
        const indexHtml = path.join(DIST_DIR, 'index.html');
        serveFile(indexHtml, res, 'index.html');
      } else {
        res.writeHead(404);
        res.end('404 Not Found: ' + cleanUrl);
      }
    }
  });
});

function serveFile(filePath, res, originalUrlName) {
  const extname = String(path.extname(filePath)).toLowerCase();
  const contentType = MIME_TYPES[extname] || 'application/octet-stream';

  fs.readFile(filePath, (error, content) => {
    if (error) {
      if(error.code == 'ENOENT') {
        res.writeHead(404);
        res.end('404 Content Not Found');
      } else {
        res.writeHead(500);
        res.end('500 Internal Server Error');
      }
    } else {
      const headers = { 'Content-Type': contentType };

      // SECURITY HEADERS
      headers['Access-Control-Allow-Origin'] = '*';
      headers['X-Content-Type-Options'] = 'nosniff';
      
      // Standard Cache Control
      if (originalUrlName.includes('service-worker.js') || originalUrlName.endsWith('index.html') || originalUrlName === '/' || originalUrlName === '/index.html') {
          // Force network check for entry point and SW
          headers['Cache-Control'] = 'no-cache, no-store, must-revalidate';
          headers['Pragma'] = 'no-cache';
          headers['Expires'] = '0';
      } else if (originalUrlName.match(/\.(js|css|png|jpg|jpeg|gif|ico)$/)) {
          // Aggressive caching for hashed assets
          headers['Cache-Control'] = 'public, max-age=31536000, immutable';
      }

      res.writeHead(200, headers);
      res.end(content, 'utf-8');
    }
  });
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Crystal Server Active on port ${PORT}`);
});