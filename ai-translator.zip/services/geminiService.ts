import { Language, UserLocation } from "../types";
import { GoogleGenAI, Modality } from "@google/genai";
import { decodeBase64, decodeAudioData } from "../utils/audioUtils";

// Declaration for Tesseract loaded via CDN
declare const Tesseract: any;

// Lazy initialization of Gemini Client
let aiClient: GoogleGenAI | null = null;

const getAI = (): GoogleGenAI | null => {
  if (aiClient) return aiClient;
  
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API Key is missing from environment variables.");
    return null;
  }

  try {
    aiClient = new GoogleGenAI({ apiKey });
    return aiClient;
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI client:", error);
    return null;
  }
};

/**
 * Translates text using the Gemini 3 Flash model for high accuracy and context awareness.
 */
export async function translateText(
  text: string,
  fromLang: Language,
  toLang: Language,
  location?: UserLocation
): Promise<string> {
  const ai = getAI();
  if (!ai) {
      return "Error: System config missing (API Key).";
  }

  try {
    const prompt = `You are a professional translator. Translate the following text from ${fromLang.name} to ${toLang.name}.
    Ensure the tone is natural and accurate. 
    Only return the translated text. Do not add quotes or explanations.
    
    Text: "${text}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'text/plain',
      },
    });

    return response.text || "Translation empty.";
  } catch (error: any) {
    console.error("Gemini Translation Error:", error);
    return "Translation unavailable. Connection error.";
  }
}

/**
 * Recognizes text from an image using Tesseract.js (Client-side OCR)
 * and then translates it using Gemini.
 */
export async function translateImage(
  base64Image: string,
  fromLang: Language,
  toLang: Language
): Promise<string> {
  try {
    const imageUrl = `data:image/jpeg;base64,${base64Image}`;
    
    // Check if Tesseract is loaded
    if (typeof Tesseract === 'undefined') {
        return "OCR Library loading... check internet.";
    }

    // Perform OCR in the browser
    const { data: { text } } = await Tesseract.recognize(imageUrl, 'eng', {
      // logger: (m: any) => console.log(m)
    });

    if (!text || text.trim().length === 0) {
      return "No text detected in image.";
    }

    // Translate the extracted text
    return await translateText(text, fromLang, toLang);
  } catch (error) {
    console.error("OCR Error:", error);
    return "Could not read image text.";
  }
}

/**
 * Uses Gemini TTS for high-quality speech.
 * Falls back to native browser synthesis if API fails or forced.
 */
export async function speakText(
  text: string,
  lang: Language,
  onEnd: () => void,
  forceNative: boolean = false
): Promise<void> {
  if (!text.trim()) {
    onEnd();
    return;
  }

  const ai = getAI();

  // Try Gemini TTS first (Unless forced to use native)
  if (!forceNative && ai && navigator.onLine) {
    try {
      const voiceName = 'Puck'; 

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voiceName },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      
      if (base64Audio) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
        const audioBuffer = await decodeAudioData(
          decodeBase64(base64Audio),
          audioCtx,
          24000, 
          1
        );

        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioCtx.destination);
        source.onended = () => {
            audioCtx.close();
            onEnd();
        };
        source.start();
        return;
      }
    } catch (e) {
      console.warn("Gemini TTS failed, falling back to native:", e);
    }
  }

  // Fallback to Native TTS with enhanced voice selection
  await speakNative(text, lang, onEnd);
}

/**
 * Helper to wait for voices to be loaded
 */
const waitForVoices = (): Promise<SpeechSynthesisVoice[]> => {
  return new Promise((resolve) => {
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      resolve(voices);
      return;
    }
    const listener = () => {
      const updatedVoices = window.speechSynthesis.getVoices();
      if (updatedVoices.length > 0) {
        window.speechSynthesis.removeEventListener('voiceschanged', listener);
        resolve(updatedVoices);
      }
    };
    window.speechSynthesis.addEventListener('voiceschanged', listener);
    
    // Timeout in case voices never load
    setTimeout(() => {
        window.speechSynthesis.removeEventListener('voiceschanged', listener);
        resolve([]);
    }, 2000);
  });
};

/**
 * Native Speech Synthesis Fallback
 */
async function speakNative(text: string, lang: Language, onEnd: () => void): Promise<void> {
  if (!window.speechSynthesis) {
    onEnd();
    return;
  }

  window.speechSynthesis.cancel();
  
  // Wait for voices to ensure we can pick the best accent
  const voices = await waitForVoices();

  const utterance = new SpeechSynthesisUtterance(text);
  const targetLangCode = lang.sttCode || lang.code;
  utterance.lang = targetLangCode;

  // Sophisticated voice matching
  let selectedVoice = 
    // 1. Try exact match (e.g., 'es-ES' for Spain Spanish)
    voices.find(v => v.lang === targetLangCode) || 
    // 2. Try loose match with underscore (Android sometimes uses es_ES)
    voices.find(v => v.lang.replace('_', '-') === targetLangCode) ||
    // 3. Try prefix match (e.g., any 'es' voice)
    voices.find(v => v.lang.startsWith(lang.code)) ||
    // 4. Default
    voices[0];

  if (selectedVoice) {
      utterance.voice = selectedVoice;
  }

  utterance.rate = 0.9; // Slightly slower for clarity
  utterance.pitch = 1.0;
  
  utterance.onend = () => onEnd();
  utterance.onerror = (e) => {
      console.error("Speech Error", e);
      onEnd();
  };

  window.speechSynthesis.speak(utterance);
}

// Deprecated
export async function generateSpeech(text: string, toLang: Language): Promise<any> {
    return null;
}