import React, { useEffect } from 'react';

const AffiliateSection: React.FC = () => {
  // Adsterra Direct Link (Smartlink)
  const AD_LINK = "https://logshandgripquarterback.com/yryb3wx87?key=bf0150f3021442b165bf61f2ba0ff4cc";

  useEffect(() => {
    // Check if the container exists before injecting script
    const container = document.getElementById('container-52c67a2e32c99ef4c8bdd1e440979d52');
    if (container) {
        const script = document.createElement('script');
        script.src = "https://logshandgripquarterback.com/52c67a2e32c99ef4c8bdd1e440979d52/invoke.js";
        script.async = true;
        script.setAttribute('data-cfasync', 'false');
        
        // Add error handling to prevent "Script error." causing issues
        script.onerror = () => {
          console.warn("External partner script failed to load.");
        };

        document.body.appendChild(script);

        return () => {
            if (document.body.contains(script)) {
                document.body.removeChild(script);
            }
        };
    }
  }, []);

  return (
    <div className="w-full mt-auto pt-6 pb-2 flex flex-col items-center justify-center animate-reveal px-2 space-y-4">
       <a
         href={AD_LINK}
         target="_blank"
         rel="noopener noreferrer"
         className="w-full max-w-sm bg-white/80 backdrop-blur-md border border-blue-100/50 shadow-sm rounded-2xl p-3 flex items-center justify-between group hover:shadow-lg transition-all duration-300 active:scale-95 cursor-pointer"
       >
         <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center text-white shadow-blue-200 shadow-lg">
                <i className="fas fa-gift animate-pulse text-sm"></i>
            </div>
            <div className="flex flex-col">
                <span className="text-[8px] font-black uppercase tracking-[0.2em] text-blue-300">Partner Offer</span>
                <span className="text-xs font-black text-slate-800 group-hover:text-blue-600 transition-colors">Support Crystal</span>
            </div>
         </div>
         <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-blue-50 transition-colors">
            <i className="fas fa-external-link-alt text-[10px] text-slate-400 group-hover:text-blue-500"></i>
         </div>
       </a>

       {/* Adsterra Banner Container */}
       <div className="w-full flex justify-center items-center overflow-hidden rounded-xl">
            <div id="container-52c67a2e32c99ef4c8bdd1e440979d52"></div>
       </div>
    </div>
  );
};

export default AffiliateSection;