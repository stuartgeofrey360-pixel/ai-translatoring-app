import React, { useState, useEffect, useRef } from 'react';
import { Language } from '../types';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { decodeBase64, encodeBase64, float32ToInt16 } from '../utils/audioUtils';
import { translateText, speakText } from '../services/geminiService';

interface UniversalInterpreterProps {
  fromLang: Language;
  toLang: Language;
  onSwitchLangs: () => void;
  onLangChange: (type: 'from' | 'to', lang: Language) => void;
}

const UniversalInterpreter: React.FC<UniversalInterpreterProps> = ({ fromLang, toLang }) => {
  const [isLiveMode, setIsLiveMode] = useState(false); // Default to Standard to save costs
  const [isActive, setIsActive] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [translation, setTranslation] = useState('');
  const [floating, setFloating] = useState(false);
  
  // --- LIVE MODE REFS ---
  const inputContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sessionRef = useRef<any>(null);

  // --- STANDARD MODE REFS ---
  const recognitionRef = useRef<any>(null);
  const silenceTimer = useRef<any>(null);

  // --- UI REFS ---
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pipVideoRef = useRef<HTMLVideoElement>(null);

  // 1. Wake Lock (Shared)
  useEffect(() => {
    let wakeLock: any = null;
    const requestWakeLock = async () => {
      if ('wakeLock' in navigator && isActive) {
        try { wakeLock = await (navigator as any).wakeLock.request('screen'); } catch (e) {}
      }
    };
    requestWakeLock();
    return () => wakeLock?.release();
  }, [isActive]);

  // 2. PiP Canvas Loop (Shared)
  useEffect(() => {
    let animId: number;
    const updateCanvas = () => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (canvas && ctx) {
            // Background
            ctx.fillStyle = '#0F172A';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Status Indicator
            ctx.font = 'bold 20px "Plus Jakarta Sans", sans-serif';
            ctx.fillStyle = isActive ? '#10B981' : '#EF4444';
            ctx.fillText(isActive ? (isLiveMode ? "● LIVE (PRO)" : "● STANDARD") : "● PAUSED", 20, 40);
            
            // Subtitles
            ctx.font = 'bold 32px "Plus Jakarta Sans", sans-serif';
            ctx.fillStyle = '#FFFFFF';
            ctx.textAlign = 'center';
            
            const text = translation || (isActive ? "Listening..." : "Ready");
            // Simple text wrapping for canvas
            const words = text.split(' ');
            let line = '';
            let y = 100;
            const maxWidth = 560;
            
            for(let n = 0; n < words.length; n++) {
              const testLine = line + words[n] + ' ';
              if (ctx.measureText(testLine).width > maxWidth && n > 0) {
                ctx.fillText(line, 300, y);
                line = words[n] + ' ';
                y += 40;
              } else {
                line = testLine;
              }
            }
            ctx.fillText(line, 300, y);
        }
        animId = requestAnimationFrame(updateCanvas);
    };
    updateCanvas();
    return () => cancelAnimationFrame(animId);
  }, [translation, isActive, isLiveMode]);

  // 3. Standard Mode Logic (Free/Cheap)
  useEffect(() => {
    // Only init if we are in Standard Mode
    if (isLiveMode) return;

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = fromLang.sttCode;

      recognition.onresult = (event: any) => {
        const text = event.results[event.results.length - 1][0].transcript;
        setTranscript(text);
        
        // Debounce translation (1.2s silence)
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
        silenceTimer.current = setTimeout(() => {
            if (text.trim().length > 0) handleStandardTranslate(text);
        }, 1200);
      };
      
      recognition.onend = () => {
          // Auto-restart if we are still active and in standard mode
          if (isActive && !isLiveMode) {
              try { recognition.start(); } catch(e) {}
          }
      };
      
      recognitionRef.current = recognition;
    }
    return () => {
        recognitionRef.current?.stop();
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
    };
  }, [fromLang, isLiveMode, isActive]);

  const handleStandardTranslate = async (text: string) => {
      try {
          const result = await translateText(text, fromLang, toLang);
          setTranslation(result);
          // Auto-speak result using NATIVE TTS (forceNative = true) to save costs
          await speakText(result, toLang, () => {}, true);
      } catch (e) { console.error(e); }
  };

  // 4. Live Mode Logic (Paid)
  const startLiveSession = async () => {
    try {
        const apiKey = process.env.API_KEY;
        if (!apiKey) return;
        const ai = new GoogleGenAI({ apiKey });
        
        // Setup Audio Contexts
        const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, sampleRate: 16000 }});
        inputContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        inputSourceRef.current = inputContextRef.current.createMediaStreamSource(stream);
        processorRef.current = inputContextRef.current.createScriptProcessor(4096, 1, 1);
        inputSourceRef.current.connect(processorRef.current);
        processorRef.current.connect(inputContextRef.current.destination);
        
        outputContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        nextStartTimeRef.current = outputContextRef.current.currentTime;

        const sessionPromise = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-12-2025',
            config: {
                responseModalities: [Modality.AUDIO],
                systemInstruction: `Translate ${fromLang.name} to ${toLang.name}. Concise.`,
            },
            callbacks: {
                onopen: () => setIsActive(true),
                onmessage: async (msg: LiveServerMessage) => {
                    const base64Audio = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                    if (base64Audio && outputContextRef.current) {
                        const audioData = decodeBase64(base64Audio);
                        const int16 = new Int16Array(audioData.buffer);
                        const float32 = new Float32Array(int16.length);
                        for(let i=0; i<int16.length; i++) float32[i] = int16[i] / 32768.0;
                        
                        const buffer = outputContextRef.current.createBuffer(1, float32.length, 24000);
                        buffer.copyToChannel(float32, 0);
                        const source = outputContextRef.current.createBufferSource();
                        source.buffer = buffer;
                        source.connect(outputContextRef.current.destination);
                        
                        const now = outputContextRef.current.currentTime;
                        const start = Math.max(now, nextStartTimeRef.current);
                        source.start(start);
                        nextStartTimeRef.current = start + buffer.duration;
                        
                        setTranslation("Speaking...");
                    }
                },
                onclose: () => cleanup(),
                onerror: () => cleanup()
            }
        });
        sessionRef.current = sessionPromise;

        // Send Input
        processorRef.current.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const pcmInt16 = float32ToInt16(inputData);
            const base64 = encodeBase64(new Uint8Array(pcmInt16.buffer));
            sessionPromise.then(s => s.sendRealtimeInput({ media: { mimeType: 'audio/pcm;rate=16000', data: base64 }}));
        };
    } catch (e) { cleanup(); }
  };

  const cleanup = () => {
      setIsActive(false);
      // Clean Live
      if (inputSourceRef.current) {
          inputSourceRef.current.disconnect();
          processorRef.current?.disconnect();
          inputContextRef.current?.close();
          outputContextRef.current?.close();
          inputSourceRef.current = null;
      }
      // Clean Standard
      if (recognitionRef.current) recognitionRef.current.stop();
  };

  const toggleSession = () => {
      if (isActive) {
          cleanup();
      } else {
          setTranslation("");
          setTranscript("");
          if (isLiveMode) {
              startLiveSession();
          } else {
              setIsActive(true);
              recognitionRef.current?.start();
          }
      }
  };

  const toggleFloat = async () => {
    if (!pipVideoRef.current || !canvasRef.current) return;
    if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setFloating(false);
    } else {
        if (pipVideoRef.current.paused) {
             const stream = canvasRef.current.captureStream(30);
             pipVideoRef.current.srcObject = stream;
             pipVideoRef.current.play();
        }
        try { await pipVideoRef.current.requestPictureInPicture(); setFloating(true); } catch (e) {}
    }
  };

  return (
    <div className="h-full flex flex-col space-y-4 animate-reveal">
      <canvas ref={canvasRef} width={600} height={200} className="hidden" />
      <video ref={pipVideoRef} className="hidden" muted autoPlay playsInline />

      {/* Header with Mode Toggle */}
      <div className="flex flex-col space-y-3 px-2">
         <div className="flex items-center justify-between">
             <div className="flex flex-col">
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-blue-300">Interpreter</span>
                <div className="flex items-center space-x-2">
                    <span className="text-xl">{fromLang.flag}</span>
                    <i className="fas fa-arrow-right text-xs text-slate-300"></i>
                    <span className="text-xl">{toLang.flag}</span>
                </div>
             </div>
             <button 
                onClick={toggleFloat}
                className={`px-3 py-2 rounded-xl flex items-center space-x-2 transition-all ${floating ? 'bg-sky-500 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}
             >
                <i className="fas fa-clone"></i>
                <span className="text-[9px] font-black uppercase tracking-tight">Float</span>
             </button>
         </div>

         {/* Mode Toggle Switch */}
         <div className="bg-slate-100 p-1 rounded-xl flex relative">
             <div className={`absolute top-1 bottom-1 w-[48%] bg-white rounded-lg shadow-sm transition-all duration-300 ${isLiveMode ? 'left-[50%]' : 'left-[1%]'}`}></div>
             <button 
               onClick={() => { cleanup(); setIsLiveMode(false); }}
               className={`flex-1 relative z-10 py-2 text-[9px] font-black uppercase tracking-widest text-center ${!isLiveMode ? 'text-sky-600' : 'text-slate-400'}`}
             >
               Standard (Free)
             </button>
             <button 
               onClick={() => { cleanup(); setIsLiveMode(true); }}
               className={`flex-1 relative z-10 py-2 text-[9px] font-black uppercase tracking-widest text-center ${isLiveMode ? 'text-sky-600' : 'text-slate-400'}`}
             >
               Live (Pro)
             </button>
         </div>
      </div>

      {/* Main Visualizer */}
      <div className="flex-1 bg-slate-900 rounded-[2.5rem] p-6 relative overflow-hidden shadow-2xl flex flex-col justify-center items-center text-center">
         {/* Background */}
         <div className={`absolute inset-0 opacity-20 transition-all duration-1000 ${isActive ? 'bg-[url("https://www.transparenttextures.com/patterns/cubes.png")] animate-pulse' : 'bg-none'}`}></div>
         
         {!isActive && (
             <div className="absolute inset-0 flex items-center justify-center bg-black/40 z-10 backdrop-blur-sm">
                 <div className="text-center text-white/50">
                     <i className="fas fa-power-off text-4xl mb-4 block"></i>
                     <span className="text-[10px] font-black uppercase tracking-widest">Standby</span>
                 </div>
             </div>
         )}

         <div className="relative z-20 w-full space-y-6">
            <div className={`transition-all duration-500 ${!isActive ? 'opacity-50 blur-[1px]' : 'opacity-100'}`}>
                {isLiveMode ? (
                     <p className="text-[10px] font-bold text-sky-400 uppercase tracking-widest mb-2">Real-time Audio Stream</p>
                ) : (
                     <p className="text-[10px] font-bold text-sky-400 uppercase tracking-widest mb-2">Detected: {transcript || "..."}</p>
                )}
            </div>

            <div className="h-[1px] w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent mx-auto"></div>

            <div className="min-h-[100px]">
                <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-2">Output</p>
                <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-200 to-emerald-400 leading-tight">
                    {translation || (isActive ? "Listening..." : "Ready")}
                </p>
            </div>
         </div>
      </div>

      {/* Action Button */}
      <div className="px-4 pb-4">
        <button
          onClick={toggleSession}
          className={`w-full py-6 rounded-[2rem] font-black uppercase text-xs tracking-[0.3em] shadow-lg transition-all duration-300 btn-squishy flex items-center justify-center space-x-3 ${
            isActive 
              ? 'bg-rose-500 text-white shadow-rose-200' 
              : (isLiveMode ? 'bg-purple-600 text-white shadow-purple-200' : 'bg-emerald-500 text-white shadow-emerald-200')
          }`}
        >
          {isActive ? (
             <>
               <span className="animate-pulse w-3 h-3 bg-white rounded-full"></span>
               <span>Stop Session</span>
             </>
          ) : (
             <>
               <i className={`fas ${isLiveMode ? 'fa-bolt' : 'fa-microphone'}`}></i>
               <span>Start {isLiveMode ? 'Pro' : 'Standard'}</span>
             </>
          )}
        </button>
      </div>
    </div>
  );
};

export default UniversalInterpreter;